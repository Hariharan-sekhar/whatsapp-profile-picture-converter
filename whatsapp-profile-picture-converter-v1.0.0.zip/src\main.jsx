import React from "react";
import { createRoot } from "react-dom/client";
import { Download, ImageUp, Palette, RotateCcw, Upload } from "lucide-react";
import "./styles.css";

const OUTPUT_SIZE = 640;
const BACKGROUNDS = [
  { id: "blur", label: "Blur" },
  { id: "white", label: "White" },
  { id: "black", label: "Black" },
  { id: "custom", label: "Color" },
];

function App() {
  const [image, setImage] = React.useState(null);
  const [fileName, setFileName] = React.useState("");
  const [error, setError] = React.useState("");
  const [background, setBackground] = React.useState("blur");
  const [customColor, setCustomColor] = React.useState("#e9f5ef");
  const [convertedImage, setConvertedImage] = React.useState("");
  const fileInputRef = React.useRef(null);
  const canvasRef = React.useRef(null);

  function handleFileChange(event) {
    const file = event.target.files?.[0];
    if (!file) return;

    const supportedTypes = ["image/jpeg", "image/png", "image/webp"];
    if (!supportedTypes.includes(file.type)) {
      setError("Please choose a JPG, PNG, or WEBP image.");
      setImage(null);
      setFileName("");
      setConvertedImage("");
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      setImage(reader.result);
      setFileName(file.name);
      setConvertedImage("");
      setError("");
    };
    reader.onerror = () => {
      setError("The image could not be loaded. Please try another file.");
      setImage(null);
      setFileName("");
      setConvertedImage("");
    };
    reader.readAsDataURL(file);
  }

  function resetImage() {
    setImage(null);
    setFileName("");
    setError("");
    setConvertedImage("");
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  }

  function drawFittedImage(context, imageElement) {
    const scale = Math.min(
      OUTPUT_SIZE / imageElement.naturalWidth,
      OUTPUT_SIZE / imageElement.naturalHeight,
    );
    const width = imageElement.naturalWidth * scale;
    const height = imageElement.naturalHeight * scale;
    const x = (OUTPUT_SIZE - width) / 2;
    const y = (OUTPUT_SIZE - height) / 2;

    context.drawImage(imageElement, x, y, width, height);
  }

  React.useEffect(() => {
    if (!image || !canvasRef.current) return;

    const imageElement = new Image();
    imageElement.onload = () => {
      const canvas = canvasRef.current;
      const context = canvas.getContext("2d");

      canvas.width = OUTPUT_SIZE;
      canvas.height = OUTPUT_SIZE;
      context.clearRect(0, 0, OUTPUT_SIZE, OUTPUT_SIZE);

      if (background === "blur") {
        const coverScale = Math.max(
          OUTPUT_SIZE / imageElement.naturalWidth,
          OUTPUT_SIZE / imageElement.naturalHeight,
        );
        const coverWidth = imageElement.naturalWidth * coverScale;
        const coverHeight = imageElement.naturalHeight * coverScale;
        const coverX = (OUTPUT_SIZE - coverWidth) / 2;
        const coverY = (OUTPUT_SIZE - coverHeight) / 2;

        context.filter = "blur(18px)";
        context.drawImage(imageElement, coverX, coverY, coverWidth, coverHeight);
        context.filter = "none";
        context.fillStyle = "rgba(255, 255, 255, 0.18)";
        context.fillRect(0, 0, OUTPUT_SIZE, OUTPUT_SIZE);
      } else {
        context.fillStyle =
          background === "black"
            ? "#000000"
            : background === "custom"
              ? customColor
              : "#ffffff";
        context.fillRect(0, 0, OUTPUT_SIZE, OUTPUT_SIZE);
      }

      drawFittedImage(context, imageElement);
      setConvertedImage(canvas.toDataURL("image/jpeg", 0.94));
    };
    imageElement.onerror = () => {
      setError("The image preview could not be converted. Please try again.");
      setConvertedImage("");
    };
    imageElement.src = image;
  }, [background, customColor, image]);

  function downloadImage() {
    if (!convertedImage) return;

    const link = document.createElement("a");
    link.href = convertedImage;
    link.download = "whatsapp-profile-picture.jpg";
    link.click();
  }

  return (
    <main className="app-shell">
      <section className="editor">
        <div className="intro">
          <p className="eyebrow">WhatsApp Profile Picture Converter</p>
          <h1>Make any image ready for your profile photo.</h1>
          <p>
            Upload a photo, keep the whole image visible, and convert it into a
            640 x 640 WhatsApp-ready square.
          </p>
        </div>

        <div className="workspace">
          <section className="upload-panel" aria-label="Image upload">
            <input
              ref={fileInputRef}
              className="file-input"
              id="imageUpload"
              type="file"
              accept="image/jpeg,image/png,image/webp"
              onChange={handleFileChange}
            />

            <label className="upload-target" htmlFor="imageUpload">
              <ImageUp size={34} aria-hidden="true" />
              <span>Choose an image</span>
              <small>JPG, PNG, or WEBP</small>
            </label>

            {fileName && <p className="file-name">{fileName}</p>}
            {error && <p className="error-message">{error}</p>}

            <div className="actions">
              <button type="button" onClick={() => fileInputRef.current?.click()}>
                <Upload size={18} aria-hidden="true" />
                Upload
              </button>
              <button type="button" className="secondary" onClick={resetImage}>
                <RotateCcw size={18} aria-hidden="true" />
                Reset
              </button>
            </div>

            <div className="control-group">
              <div className="control-title">
                <Palette size={18} aria-hidden="true" />
                <span>Background</span>
              </div>
              <div className="background-options" role="group" aria-label="Background">
                {BACKGROUNDS.map((option) => (
                  <button
                    type="button"
                    className={background === option.id ? "option active" : "option"}
                    key={option.id}
                    onClick={() => setBackground(option.id)}
                  >
                    {option.label}
                  </button>
                ))}
              </div>
              {background === "custom" && (
                <label className="color-control">
                  <span>Pick color</span>
                  <input
                    type="color"
                    value={customColor}
                    onChange={(event) => setCustomColor(event.target.value)}
                  />
                </label>
              )}
            </div>
          </section>

          <section className="preview-panel" aria-label="Converted image preview">
            <div className="preview-layout">
              <div className="square-preview">
                {convertedImage ? (
                  <img src={convertedImage} alt="640 by 640 converted preview" />
                ) : (
                  <div className="empty-preview">
                    <ImageUp size={44} aria-hidden="true" />
                    <span>Your square preview will appear here</span>
                  </div>
                )}
              </div>

              <div className="profile-preview" aria-label="Circular WhatsApp preview">
                {convertedImage ? (
                  <img src={convertedImage} alt="Circular WhatsApp profile preview" />
                ) : (
                  <ImageUp size={36} aria-hidden="true" />
                )}
              </div>
            </div>

            <div className="download-row">
              <p className="preview-caption">
                Output: {OUTPUT_SIZE} x {OUTPUT_SIZE}. The full image stays
                visible; background fills the empty space.
              </p>
              <button
                type="button"
                className="download-button"
                onClick={downloadImage}
                disabled={!convertedImage}
              >
                <Download size={18} aria-hidden="true" />
                Download
              </button>
            </div>

            <canvas
              ref={canvasRef}
              className="conversion-canvas"
              width={OUTPUT_SIZE}
              height={OUTPUT_SIZE}
              aria-hidden="true"
            />
          </section>
        </div>
      </section>
    </main>
  );
}

createRoot(document.getElementById("root")).render(<App />);

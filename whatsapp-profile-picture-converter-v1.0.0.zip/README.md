# WhatsApp Profile Picture Converter

A React app for turning any uploaded image into a WhatsApp-ready profile picture.

## Current phase

- Image upload
- JPG, PNG, and WEBP validation
- Full-image fit into a `640 x 640` square canvas
- Blur, white, black, and custom color backgrounds
- Square preview
- Circular WhatsApp-style preview
- JPG download
- Reset control

## Next phase

- Add manual zoom and positioning
- Add rotate controls
- Add drag-and-drop upload

## Run locally

Install dependencies, then start the development server:

```bash
npm install
npm run dev
```

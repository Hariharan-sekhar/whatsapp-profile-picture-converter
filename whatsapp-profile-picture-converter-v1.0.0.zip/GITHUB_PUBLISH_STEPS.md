# GitHub Publish Steps

## Option 1: Publish with GitHub Website

1. Go to https://github.com/new
2. Create a new repository named `whatsapp-profile-picture-converter`.
3. Keep it public or private, whichever you prefer.
4. Do not add a README, `.gitignore`, or license on GitHub because this project already has local files.
5. Upload the project files from this folder.
6. Commit the upload on GitHub.

## Option 2: Publish with Command Prompt

After creating an empty GitHub repository, run these commands inside the project folder:

```bash
git init
git add .
git commit -m "Release v1.0.0"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/whatsapp-profile-picture-converter.git
git push -u origin main
```

Replace `YOUR_USERNAME` with your GitHub username.

## Important

The project should not upload these folders:

- `node_modules`
- `dist`
- `.npm-cache`

They are already listed in `.gitignore`.
